import org.apache.log4j.{Level, Logger}
import org.apache.spark.streaming._
import org.apache.spark.{SparkConf, SparkContext}

object Spark {
  def main(args: Array[String]) {

    Logger.getLogger("org").setLevel(Level.ERROR)
    Logger.getLogger("akka").setLevel(Level.ERROR)

    val sparkConf = new SparkConf().setAppName("Sample App").setMaster("local[2]")
    val ssc = new StreamingContext(sparkConf, Seconds(30))

    val lines = ssc.socketTextStream("localhost", 33001)

    // Transform input for RDD
    val cols = lines.map(_.split(" ").toList)

    // Get distinct api and count
    val api = cols.map (t => t(2).substring(5, 8)).map(t => (t, 1))
    val grouped = api.reduceByKey(_+_)
    grouped.print()

    // Get users who made requests from more than one unique IP-address
    val users = cols.map(t => (t(0), t(1))).transform(rdd => rdd.distinct).map{case (a,b) => (b,1)}
    val grouped_users = users.reduceByKey(_+_)
    val filtered = grouped_users.filter(t => t._2 > 1)
    filtered.print()

    ssc.start()
    ssc.awaitTermination()
  }
}